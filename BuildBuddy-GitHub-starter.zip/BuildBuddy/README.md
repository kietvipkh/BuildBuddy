# Build Buddy — Fabric 26.2 prototype

This is the first GitHub Actions build scaffold for Minecraft Java 26.2 / Fabric.

## Build on GitHub
1. Create a new empty GitHub repository.
2. Upload the contents of this folder to the repository (keep `.github/workflows/build.yml`).
3. Open the repository's **Actions** tab.
4. Select **Build Fabric mod** → **Run workflow**.
5. When the run finishes, download the `BuildBuddy-jar` artifact.

## In-game commands in this prototype
- `/build` — help
- `/build list` — lists `.litematic` files in `schematics/` and `config/litematica/schematics/` under the game directory
- `/build select <file>` — selects a listed file
- `/build status`, `/build pause`, `/build resume`, `/build stop`

## Important status
This is only a build-pipeline and command prototype. It does **not** yet parse Litematica NBT, render a hologram, compare blocks, or place/repair blocks. Do not treat it as the finished auto-builder. Actual building features need further implementation and in-game testing. It does not bypass server protections or anti-cheat.

Minecraft 26.2 requires Java 25 for this toolchain. Fabric 26.2 setup values are based on Fabric's published 26.2 guidance.
