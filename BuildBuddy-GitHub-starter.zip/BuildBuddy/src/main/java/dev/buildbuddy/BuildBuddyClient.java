package dev.buildbuddy;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.network.chat.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

public final class BuildBuddyClient implements ClientModInitializer {
    private static final AtomicReference<String> selected = new AtomicReference<>("");
    private static volatile String state = "IDLE";
    private static volatile String note = "Chưa chọn công trình.";

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("build")
                .executes(ctx -> {
                    ctx.getSource().sendFeedback(Component.literal("Build Buddy: /build list | /build select <ten-file> | /build status | /build pause | /build resume | /build stop"));
                    return 1;
                })
                .then(ClientCommandManager.literal("list").executes(ctx -> {
                    List<Path> files = findSchematics();
                    if (files.isEmpty()) {
                        ctx.getSource().sendFeedback(Component.literal("Không tìm thấy .litematic. Thư mục đã kiểm tra: " + schematicDir()));
                    } else {
                        ctx.getSource().sendFeedback(Component.literal("Tìm thấy " + files.size() + " file .litematic:"));
                        files.stream().limit(30).forEach(p -> ctx.getSource().sendFeedback(Component.literal("- " + p.getFileName())));
                    }
                    return 1;
                }))
                .then(ClientCommandManager.literal("select")
                    .then(ClientCommandManager.argument("file", StringArgumentType.greedyString()).executes(ctx -> {
                        String name = StringArgumentType.getString(ctx, "file");
                        Path match = findSchematics().stream().filter(p -> p.getFileName().toString().equalsIgnoreCase(name)
                            || p.getFileName().toString().equalsIgnoreCase(name + ".litematic")).findFirst().orElse(null);
                        if (match == null) {
                            ctx.getSource().sendFeedback(Component.literal("Không tìm thấy file: " + name + ". Dùng /build list."));
                            return 0;
                        }
                        selected.set(match.toAbsolutePath().toString());
                        note = "Đã chọn file; bộ đọc cấu trúc sẽ được bổ sung ở bản tiếp theo.";
                        ctx.getSource().sendFeedback(Component.literal("Đã chọn: " + match.getFileName()));
                        return 1;
                    })))
                .then(ClientCommandManager.literal("status").executes(ctx -> {
                    ctx.getSource().sendFeedback(Component.literal("Build Buddy | trạng thái: " + state + " | file: " + (selected.get().isBlank() ? "chưa chọn" : Path.of(selected.get()).getFileName()) + " | " + note));
                    return 1;
                }))
                .then(ClientCommandManager.literal("pause").executes(ctx -> { state = "PAUSED"; ctx.getSource().sendFeedback(Component.literal("Đã tạm dừng tác vụ.")); return 1; }))
                .then(ClientCommandManager.literal("resume").executes(ctx -> { state = "READY"; ctx.getSource().sendFeedback(Component.literal("Đã tiếp tục trạng thái tác vụ.")); return 1; }))
                .then(ClientCommandManager.literal("stop").executes(ctx -> { state = "IDLE"; note = "Tác vụ đã dừng."; ctx.getSource().sendFeedback(Component.literal("Đã dừng.")); return 1; }))
            )
        );
    }

    private static Path schematicDir() {
        return FabricLoader.getInstance().getGameDir().resolve("schematics");
    }

    private static List<Path> findSchematics() {
        Path game = FabricLoader.getInstance().getGameDir();
        Path[] dirs = { game.resolve("schematics"), game.resolve("config").resolve("litematica").resolve("schematics") };
        try (Stream<Path> paths = Stream.of(dirs).filter(Files::isDirectory).flatMap(dir -> {
            try { return Files.list(dir); } catch (IOException e) { return Stream.empty(); }
        })) {
            return paths.filter(Files::isRegularFile)
                .filter(p -> p.getFileName().toString().toLowerCase().endsWith(".litematic"))
                .sorted(Comparator.comparing(p -> p.getFileName().toString().toLowerCase()))
                .toList();
        }
    }
}
